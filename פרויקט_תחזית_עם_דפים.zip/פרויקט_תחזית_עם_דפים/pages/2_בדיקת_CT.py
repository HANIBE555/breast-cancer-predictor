
import streamlit as st

st.markdown("""
<style>
html, body, [class*="css"] {
    direction: rtl;
    text-align: right;
}
</style>
""", unsafe_allow_html=True)

st.title("🖼️ בדיקת CT לזיהוי גידול")
st.info("המודול הזה עדיין בבנייה. אנא חזור בהמשך.")
